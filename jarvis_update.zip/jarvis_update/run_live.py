from exchange.exchange import Exchange
from utils.config import TELEGRAM_BOT_TOKEN
from utils.risk_manager import RiskManager
from utils.portfolio import PortfolioManager
from utils.updater import Updater
from loguru import logger
import time
import requests
import pandas as pd

def send_telegram(message):
    if not TELEGRAM_BOT_TOKEN:
        return
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    try:
        requests.post(url, data={"chat_id": "@your_channel_or_user_id", "text": message})
    except Exception as e:
        logger.error(f"Telegram gönderilemedi: {e}")

def analyze(symbol, client):
    try:
        klines = client.get_klines(symbol=symbol, interval='1m', limit=100)
        df = pd.DataFrame(klines, columns=['open_time','open','high','low','close','volume',
                                           'close_time','quote_asset_volume','trades','taker_base','taker_quote','ignore'])
        df['close'] = df['close'].astype(float)
        df['volume'] = df['volume'].astype(float)
        df['EMA20'] = df['close'].ewm(span=20, adjust=False).mean()
        df['EMA50'] = df['close'].ewm(span=50, adjust=False).mean()
        delta = df['close'].diff()
        up = delta.clip(lower=0)
        down = -1*delta.clip(upper=0)
        ema_up = up.ewm(com=13, adjust=False).mean()
        ema_down = down.ewm(com=13, adjust=False).mean()
        rs = ema_up / ema_down
        df['RSI'] = 100 - (100 / (1 + rs))
        last = df.iloc[-1]
        if last['RSI'] < 30 and last['close'] > last['EMA20']:
            return "BUY"
        elif last['RSI'] > 70 and last['close'] < last['EMA20']:
            return "SELL"
        else:
            return None
    except Exception as e:
        logger.error(f"{symbol} analiz hatası: {e}")
        return None

def main():
    ex = Exchange()
    rm = RiskManager()
    pf = PortfolioManager(total_usdt=100)
    updater = Updater("https://yourrepo.com/api")  # Repo URL
    symbols = ex.get_all_usdt_symbols()
    delay = 2

    logger.info("🚀 Akıllı çoklu coin trading başladı...")

    while True:
        updater.check_updates()
        for symbol in symbols:
            if not rm.can_trade():
                continue
            signal = analyze(symbol, ex.client)
            trade_amount = pf.allocate_trade(5)
            if signal == "BUY":
                order = ex.buy(symbol, trade_amount)
                send_telegram(f"💹 BUY ORDER: {symbol} x {trade_amount} USDT")
                rm.record_trade(0)  # Profit/loss tahmini eklenebilir
            elif signal == "SELL":
                order = ex.sell(symbol, trade_amount)
                send_telegram(f"📉 SELL ORDER: {symbol} x {trade_amount} USDT")
                rm.record_trade(0)
            pf.release_trade(trade_amount)
            time.sleep(delay)

if __name__ == "__main__":
    main()
